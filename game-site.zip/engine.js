// NovaEngine v1 — shared loop, input, particles, highscore, audio
const ENGINE = (function(){
  const POOL_MAX=420; const P=[]; let N=POOL_MAX;
  for(let i=0;i<POOL_MAX;i++) P.push({x:0,y:0,vx:0,vy:0,size:1,color:'#fff',life:0,maxLife:1,tp:'c'});
  function free(p){p.life=0;} function pool(){return P[--N];}
  function spawn(x,y,color,size,count,kind='circle'){ while(count--){if(N<=0)return;const p=pool();p.x=x;p.y=y;p.size=size*(.6+.8*Math.random());const a=Math.random()*Math.PI*2;const m=size/6;p.vx=Math.cos(a)*(1.5+Math.random()*2)*m;p.vy=Math.sin(a)*(1.5+Math.random()*2)*m;p.color=color;p.maxLife=.45+.55*Math.random();p.life=p.maxLife;p.tp=kind;N++;}}
  function update(dt){for(let i=POOL_MAX-N;i<POOL_MAX;i++){const p=P[i];let f=1.1;if(p.tp==='spark')f=2.1;else if(p.tp==='square')f=1.5;p.life-=dt*f;if(p.life<=0){free(p);N++;}}}
  function draw(ctx){ctx.save();ctx.globalCompositeOperation='lighter';for(let i=POOL_MAX-N;i<POOL_MAX;i++){const p=P[i];if(p.life<=0)continue;ctx.globalAlpha=Math.max(0,p.life/p.maxLife);ctx.fillStyle=p.color;if(p.tp==='circle'){ctx.beginPath();ctx.arc(p.x,p.y,p.size*p.life/p.maxLife,0,Math.PI*2);ctx.fill()}else if(p.tp==='square'){ctx.fillRect(p.x,p.y,p.size*p.life/p.maxLife,p.size*p.life/p.maxLife)}else{ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.lineTo(p.x+p.vx,p.y+p.vy);ctx.lineTo(p.x+p.vx-.7*p.vy,p.y+p.vy+.7*p.vx);ctx.closePath();ctx.fill()}}ctx.restore()}
  function clearPool(){N=POOL_MAX;for(let i=0;i<POOL_MAX;i++)P[i].life=0;}
  const HIGH_KEY='nova-highscores';
  const H={get(id){try{return JSON.parse(localStorage.getItem(HIGH_KEY)||'{}')[id]||0}catch(e){return 0}},set(id,v){try{const h=JSON.parse(localStorage.getItem(HIGH_KEY)||'{}');if(v>(h[id]||0)){h[id]=v;localStorage.setItem(HIGH_KEY,JSON.stringify(h))}}catch(e){}}};
  class AUD{constructor(){this.ctx=null;this.muted=true;} init(){try{this.ctx=new(window.AudioContext||window.webkitAudioContext);this.muted=false}catch(e){}} toggleMute(){this.ctx?(this.ctx.close(),this.ctx=null,this.muted=true):(this.init());} play(type){if(this.muted||!this.ctx)return;const t=this.ctx.currentTime,o=this.ctx.createOscillator(),g=this.ctx.createGain();const base={'click':440,'tap':330,'pop':660,'good':880,'bad':150,'win':523.25,'win2':783.99,'level':659.25}[type]||440;o.type=type==='bad'?'sawtooth':'sine';o.frequency.setValueAtTime(base,t);o.frequency.exponentialRampToValueAtTime(Math.max(80,base*.25),t+.11);g.gain.setValueAtTime(type==='bad'?.12:.09,t);g.gain.exponentialRampToValueAtTime(.001,t+((type==='win'||type==='win2')?0.35:0.1));o.connect(g);g.connect(this.ctx.destination);o.start(t);o.stop(t+.15);}}
  const KB={keys:{},down(code){this.keys[code]=true;},up(code){delete this.keys[code];},hit(c){return!!this.keys[c];}};
  const PT={x:0,y:0,lastX:0,lastY:0,down:false,released:false,dx:0,dy:0,button:0,action:0};
  let RAF=null,PAUSED=false,LT=performance.now();
  function loop(cb){const tick=t=>{if(PAUSED)return requestAnimationFrame(tick);const dt=(t-LT)/1000;LT=t;if(cb(dt)===false){LT=t;return;}RAF=requestAnimationFrame(tick);};RAF=requestAnimationFrame(tick);}
  function pauseAll(){PAUSED=true;cancelAnimationFrame(RAF);}
  function resumeAll(){PAUSED=false;LT=performance.now();}
  return {P:POOL_MAX,spawn,update,draw,clearPool,HIGH:H,AUDIO:new AUD(),KB,PT,loop,pauseAll,resumeAll};
})();
console.log('%cNovaEngine ready','color:#22d3ee;font-weight:bold');
