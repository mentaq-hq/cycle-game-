(function(){'use strict';
const E=ENGINE; const GAMES=[{id:'snake',title:'Neon Snake',icon:'🐍',desc:'Grow long, eat glowing food.',color:'#22d3ee',badge:'classic',pads:'none'},
{id:'2048',title:'2048',icon:'🔢',desc:'Slide & merge tiles.',color:'#a855f7',badge:'puzzle',pads:'dpad'},
{id:'memory',title:'Memory Blitz',icon:'🧠',desc:'Match neon cards.',color:'#f472b6',badge:'brain',pads:'none'},
{id:'tictactoe',title:'Tic-Tac-Toe & Gomoku',icon:'⭕➕',desc:'vs AI, easy & expert.',color:'#4ade80',badge:'vs AI',pads:'none'},
{id:'featherdash',title:'Feather Dash',icon:'🪶',desc:'Tap to fly, dodge pillars.',color:'#fbbf24',badge:'runner',pads:'none'},
{id:'spacejump',title:'Space Jump',icon:'🚀',desc:'Jump over walls.',color:'#ef4444',badge:'dodge',pads:'none'},
{id:'brickblaster',title:'Brick Blaster',icon:'🧱',desc:'Smash all bricks.',color:'#38bdf8',badge:'classic',pads:'none'},
{id:'bubblepop',title:'Bubble Pop',desc:'Pop, chain combos.',icon:'🫧',color:'#c084fc',badge:'relax',pads:'none'},
{id:'quadrant',title:'Quadrant Reflex',desc:'Tap the flash zone.',icon:'◉◉',color:'#22d3ee',badge:'skill',pads:'none'},
{id:'mathracer',title:'Math Racer',desc:'Crack math before time.',icon:'➗',color:'#4ade80',badge:'math',pads:'mathracer'}];
const CODES={up:'ArrowUp',down:'ArrowDown',left:'ArrowLeft',right:'ArrowRight',space:'Space',enter:'Enter'};
let showing=false,inst=null,persist=null,LT=performance.now(),PAUSED=false,muted=false;
const CTX_ID='__nvctx__', CW=800, CH=600;

const $=s=>document.querySelector(s); const $$=s=>document.querySelectorAll(s);
const hub=$('#hub-view'), gv=$('#game-view'), grid=$('#game-grid'), canvas=$('#game-canvas');
const scoreEl=$('[data-score]'),highEl=$('[data-high]'),comboEl=$('[data-combo]'),bestEl=$('[data-best]');
const hintEl=$('#controls-hint'), padEl=$('#game-pads');
const pauseOv=$('#pause-overlay'), backBtn=$('.back-btn'), soundBtn=$('.sound-btn');
if(soundBtn) soundBtn.onclick=()=>{muted=!muted;if(muted){soundBtn.innerHTML='🔇';E.AUDIO.toggleMute()}else{soundBtn.innerHTML='🔊';E.AUDIO.init()}};
if(document.querySelector('.cb-btn')) document.querySelector('.cb-btn').onclick=()=>document.body.classList.toggle('colorblind');
if(document.querySelector('.play-again')) document.querySelector('.play-again').onclick=()=>startGame(persist);
if($('.play-menu')) $('.play-menu').onclick=goHome;
if(backBtn) backBtn.onclick=goHome;

const PT={x:0,y:0,dx:0,dy:0,down:false,tapX:0,tapY:0,consumed:false};
E.KB={keys:{},push(c){this.keys[c]=true;},pop(c){delete this.keys[c];},hit(c){return!!this.keys[c];}};
window.addEventListener('keydown',e=>{if(['ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Space'].indexOf(e.code)!==-1)e.preventDefault();E.KB.push(e.code);});
window.addEventListener('keyup',e=>{E.KB.pop(e.code);});
canvas.addEventListener('pointerdown',e=>{PT.down=true;PT.tapX=e.clientX;PT.tapY=e.clientY;inst&&inst.tap(PT.tapX,PT.tapY)}, {passive:false});
canvas.addEventListener('pointermove',e=>{PT.x=e.clientX;PT.y=e.clientY;inst&&inst.pointer(e.clientX,e.clientY)}, {passive:false});
canvas.addEventListener('pointerup',e=>{PT.down=false;PT.consumed=false}, {passive:false});
canvas.addEventListener('pointercancel',e=>{PT.down=false;PT.consumed=false});

function hex4(h){return '#' + h.replace(/^#?(\w)(\w)(\w)$/,'$1$1$2$2$3$3').toUpperCase()}
function setMeta(c){document.title=c.title+' — NovaArcade';}
function buildHub(){gv.hidden=true;hub.hidden=false;grid.innerHTML='';GAMES.forEach(g=>{const el=document.createElement('button');el.className='game-card focus-ring';el.setAttribute('aria-label','Play '+g.title);el.innerHTML='<div class="card-icon" style="background:'+hex4(g.color)+';color:#040810">'+g.icon+'</div><div class="card-title">'+g.title+'</div><div class="card-desc">'+g.desc+'</div><div class="badge">'+g.badge+'</div>';el.onclick=()=>startGame(g.id);grid.appendChild(el)});}
function resizeCanvas(){const w=Math.min(canvas.parentElement.clientWidth,CW);canvas.style.width=w+'px';canvas.style.height=(w/CH*CH)+'px';canvas[CTX_ID]=ctx;ctx.setTransform(w/CW,0,0,w/CH,0,0);}
function resetHUD(){scoreEl.textContent='0';highEl.textContent=E.HIGH.get(persist);hideCombo();bestEl.textContent='—'}
function startGame(id){persist=id;const c=GAMES.find(x=>x.id===id);if(!c)return;hub.hidden=true;gv.hidden=true;showing=true;resizeCanvas();inst=null;const g=GAMES.find(x=>x.id===id);hintEl.innerHTML=g.hint||'';padEl.innerHTML='';
 if(g.pads==='dpad')padEl.innerHTML='<div class="dpad"><button class="nkey dkey dk-up" data-k=up>▲</button><button class="nkey dkey dk-left" data-k=left>◀</button><button class="nkey dkey dk-down" data-k=down>▼</button><button class="nkey dkey dk-right" data-k=right>▶</button></div>';
 else if(g.pads==='mathracer'){}else if(g.pads==='num')padEl.innerHTML='<div class="num-pad"><button class="nkey d0">0</button><button class="nkey d1">1</button><button class="nkey d2">2</button><button class="nkey d3">3</button><button class="nkey d4">4</button><button class="nkey d5">5</button><button class="nkey d6">6</button><button class="nkey d7">7</button><button class="nkey d8">8</button><button class="nkey d9">9</button><button class="nkey dbk">⌫</button><button class="nkey done">➤</button></div>';
 const pads=padEl.querySelectorAll('button');pads.forEach(b=>{b.onpointerdown=e=>e.preventDefault();b.onclick=(ev)=>{const k=b.dataset.k;if(k&&CODES[k]){E.KB.push(CODES[k]);b.addEventListener('pointerup',()=>E.KB.pop(CODES[k]),{once:true})}}});
 canvas.width=CW;canvas.height=CH;
 const api={ctx:canvas.getContext('2d'),w:CW,h:CH,input(a){return E.KB.hit(CODES[a])},tap(x,y){PT.tapX=x;PT.tapY=y;PT.consumed=true;},pointer(x,y){PT.x=x;PT.y=y;},score(v){scoreEl.textContent=v;E.HIGH.set(persist,v);},high:{get(id){return E.HIGH.get(id)},set(id,v){E.HIGH.set(id,v)}},audio:E.AUDIO,spawn:E.spawn,pauseAll:E.pauseAll,resumeAll:E.resumeAll,config:g};
 try{inst=g.factory(canvas,api)}catch(err){console.error('init '+id+':',err);inst=null}resizeCanvas();}
function endGame(score,title,subtitle){if(showing){showing=false;try{if(inst.cleanup)inst.cleanup()}catch(e){}}removePads();showModal(title,score,subtitle||'')}
function goHome(){if(inst){try{if(inst.cleanup)inst.cleanup()}catch(e){}}hub.hidden=false;gv.hidden=false;showing=false;inst=null;}
function removePads(){padEl.innerHTML=''}
function showModal(title,score,sub){$('#modal-back').style.display='flex';$('#modal-back').querySelector('.modal').innerHTML='<h2>'+title+'</h2><span class="big-score">'+score.toLocaleString()+'</span><p class="sub">'+sub+'</p><button class="btn primary play-again">Play again</button><button class="btn play-menu">Main menu</button>';}
function hideModal(){$('#modal-back').style.display='none'}
function showCombo(n){$('#streak-box').style.display='flex';comboEl.textContent='x'+n}
function hideCombo(){$('#streak-box').style.display='none'}
function setBest(ms){bestEl.textContent=ms==null?'—':ms+'ms'}

function loop(t){if(PAUSED)return requestAnimationFrame(loop);const dt=(t-LT)/1000;LT=t;if(showing&&inst){try{inst.update(dt);inst.draw(canvas[CTX_ID])}catch(e){console.error('tick:',e)}}requestAnimationFrame(loop)}
requestAnimationFrame(loop);
function pauseAll(){PAUSED=true}
function resumeAll(){PAUSED=false;LT=performance.now()}
window.addEventListener('visibilitychange',()=>{if(document.hidden){E.KB.keys={};pauseAll();if(pauseOv)pauseOv.classList.add('show')}else{resumeAll();if(pauseOv)pauseOv.classList.remove('show')}});
window.addEventListener('load',()=>{if('serviceWorker' in navigator){navigator.serviceWorker.register('/sw.js').then(r=>{}).catch(e=>{});setTimeout(function(){var dp;if(localStorage.getItem('nav-install')==null)navInstallPrompt()},8000)}});
buildHub();
})();
