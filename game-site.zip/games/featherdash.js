(function(){
  const GRAV=1900, FLAP=-545, BIRD_W=26, BIRD_H=22, GROUND=H-58, SPEED0=300;
  function factory(canvas,api){const C=api.ctx,W=api.w,H=api.h;let birdY=H/2,birdV=0,obstacles=[],score=0,high=api.high.get(api.config.gameId),started=false,dying=false,speed=SPEED0;
   let lastObsX=0,BEST=api.high.get(api.config.gameId),trailAcc=0;
   const KEY={ArrowUp:'ArrowUp',ArrowDown:'ArrowDown',ArrowLeft:'ArrowLeft',ArrowRight:'ArrowRight'};
   function reset(){birdY=H/2;birdV=0;obstacles=[];score=0;speed=SPEED0;started=false;dying=false;lastObsX=0}
   function flap(){birdV=FLAP;E.spawn(birdX(),birdY+BIRD_H/2,'#fbbf24',7,14,'circle')}
   function birdX(){return 150}
   function obsL(){return (obstacles.length?obstacles[obstacles.length-1].x:0)}
   function update(dt){if(dying)return;if(!started){if(E.KB.hit('ArrowUp')||E.KB.hit('Space')){started=true}}
     if(started){birdV+=GRAV*dt;birdY+=birdV*dt;speed+=dt*3;const moved=obstacles.map(o=>{o.x-=speed*dt;o.y-=0;return o});if(trailAcc>0.07){trailAcc-=0.07;E.spawn(birdX()-BIRD_W/2,birdY+BIRD_H/2,'#fbbf24',4,6)}if(lastObsX<W-380){const gapH=150+Math.random()*110;obstacles.push({x:lastObsX+W-30,gapTop:50+Math.random()*(H-GROUND-gapH-60),gapH:gapH,h:H-lastObsX%1})};for(let i=obstacles.length-1;i>=0;i--){if(obstacles[i].x<-120){obstacles.splice(i,1);score++}}}
     const b={l:birdX()-BIRD_W/2,r:birdX()+BIRD_W/2,t:birdY,Bottom:birdY+BIRD_H};
     if(b.Bottom>H-40||b.t<0){die()}else{obstacles.forEach(o=>{if(b.r>o.x&&b.l<o.x+110&&(b.t<o.gapTop||b.Bottom>o.gapTop+o.gapH)){die()}});}
     }
   function die(){if(dying)return;dying=true;E.audio.play('bad');E.spawn(birdX(),birdY+BIRD_H/2,'#fbbf24',8,20);END(score(),'Game Over','Feather scored '+score)}
   const onClick=function(x,y){if(!started||dying){reset();started=true}else flap()};window.addEventListener('pointerdown',(e)=>onClick(e.clientX,e.clientY),{passive:false});
   function draw(){const P=performance.now()/300%2;C.fillStyle='#070b1f';C.fillRect(0,0,W,H);C.fillStyle='#0d162b';C.fillRect(0,H-GROUND-60,W,GROUND+60);C.strokeStyle='#3aa3ff';C.lineWidth=2.5;C.beginPath();C.moveTo(0,H-GROUND);C.lineTo(W,H-GROUND);C.stroke();
     const grad=C.createLinearGradient(0,0,0,H);grad.addColorStop(0,'#091226');grad.addColorStop(1,'#152642');C.fillStyle=grad;
     for(let o of obstacles){const g=C.createLinearGradient(o.x,o.gapTop,o.x+110,o.gapTop);g.addColorStop(0,'#14203a');g.addColorStop(1,'#0f182e');C.fillStyle=g;C.shadowBlur=6;C.shadowColor='#22d3ee';C.fillStyle='#0d162b';C.fillRect(o.x,o.gapTop,110,o.gapTop);C.fillRect(o.x,o.gapTop+o.gapH,110,H-o.gapTop-o.gapH);C.fillStyle='#22d3ee';C.strokeStyle='#8fd3ff';C.lineWidth=2;C.strokeRect(o.x+1,o.gapTop+1,108,o.gapH);C.shadowBlur=0}
     C.fillStyle='#fbbf24';C.shadowBlur=12;C.shadowColor='#f472b6';C.beginPath();C.arc(birdX(),birdY+BIRD_H/2,BIRD_H/2,0,Math.PI*2);C.fill();C.shadowBlur=0;C.fillStyle='#fff';C.font='bold 15px system-ui';C.textAlign='left';C.fillText('SCORE  '+score,10,H-14);C.textAlign='right';C.fillText('BEST  '+BEST,W-10,H-14);
     if(!started){C.fillStyle='rgba(3,6,13,.6)';C.fillRect(0,0,W,H);C.fillStyle='#fff';C.font='bold 24px system-ui';C.textAlign='center';C.fillText('TAP TO FLY',W/2,H/2-10);C.font='16px system-ui';C.fillText('tap/space to flap · dodge the neon pillars',W/2,H/2+20)}
     if(dying){C.fillStyle='rgba(3,6,13,.78)';C.fillRect(0,0,W,H);C.fillStyle='#ef4444';C.font='bold 30px system-ui';C.textAlign='center';C.fillText('CRASHED!',W/2,H/2-14);C.fillStyle='#fff';C.font='17px system-ui';C.fillText('tap anywhere to restart',W/2,H/2+16)}}
   return{update,draw};}
  window.Games={featherdash:factory};
})();