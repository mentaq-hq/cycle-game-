(function(){
  const PALETTE=['#ff6b6b','#fca5a5','#fdba74','#fcd34d','#fde047','#bef264','#86efac','#6ee7b7','#4ade80','#2dd4bf','#38bdf8','#7dd3fc','#a5f3fc','#c084fc','#e879f9','#fb7185'];
  function factory(canvas,api){const C=api.ctx,W=api.w,H=api.h;let bubbles=[],score=0,high=api.high.get(api.config.gameId),started=false,dying=false,timeLeft=60,combo=0,lastTapT=0,timerAcc=0,swayAcc=0,BEST=api.high.get(api.config.gameId);
   function reset(){bubbles=[];score=0;high=api.high.get(api.config.gameId);started=false;dying=false;timeLeft=60;combo=0;lastTapT=0;timerAcc=0;swayAcc=0}
   function spawn(){const r=26+Math.random()*22;const gold=Math.random()<.08;const color=gold?'#ffd60a':PALETTE[Math.floor(Math.random()*PALETTE.length)];bubbles.push({x:10+Math.random()*(W-40),y:H+r,vy:25+Math.random()*20,r:r,phase:Math.random()*Math.PI*2,color:color,gold:gold})}
   function update(dt){if(!started&&performance.now()>1500)started=true;if(dying)return;timerAcc+=dt;if(started){timeLeft-=dt;if(timeLeft<=0){dying=true;END(score(),'Time Up!','Bubbles popped '+score)}}if(!started){for(let i=0;i<3;i++)spawn()}else while(bubbles.length<14)spawn();
     for(let i=bubbles.length-1;i>=0;i--){let b=bubbles[i];b.y-=b.vy*dt*b.vy/35;b.vy*=0.99;b.sway=Math.sin((H-b.y)*0.015+b.phase)*0.8}
   }
   function popAt(x,y){const now=performance.now();if(!started&&now<1500)return;for(let i=bubbles.length-1;i>=0;i--){const b=bubbles[i];const dx=x-b.x,dy=y-(b.y+swayAcc*dt),dist=Math.sqrt(dx*dx+dy*dy);if(dist<b.r){bubbles.splice(i,1);combo=now-lastTapT<750?combo+1:1;const mult=Math.min(3,1+Math.floor(combo/3));const pts=(b.gold?3:1)*10*mult;score+=pts;api.score(score);E.spawn(b.x,b.y,b.color,9,16,'circle');E.spawn(b.x,b.y,'#fff',4,8);lastTapT=now;break}}}
   const click=function(evX,evY){popAt(evX,evY)};window.addEventListener('pointerdown',(e)=>click(e.clientX,e.clientY),{passive:false})
   function draw(){C.fillStyle='#060a14';C.fillRect(0,0,W,H);swayAcc+=dt*C?dt:0
     for(const b of bubbles){const g=C.createRadialGradient(b.x-b.r*0.3,b.y-b.r*0.3,b.r*0.25,b.x,b.y,b.r);g.addColorStop(0,b.gold?'#fff5d6':'#ffffff');g.addColorStop(.4,b.color);g.addColorStop(1,'#081222');C.fillStyle=g;C.beginPath();C.arc(b.x,b.y,b.r,0,Math.PI*2);C.fill();C.strokeStyle=b.gold?'#fbbf24':'rgba(255,255,255,.25)';C.lineWidth=2;C.beginPath();C.arc(b.x,b.y,b.r-3,0,Math.PI*2);C.stroke()}
     C.shadowBlur=0;C.fillStyle='#162038';C.fillRect(0,H-34,W,34);C.fillStyle='#2a3f66';C.fillRect(0,H-34,timeLeft/60*(W-4)/1-4,34)
     C.fillStyle='#9aa6bc';C.font='bold 15px system-ui';C.textAlign='left';C.fillText('SCORE  '+score,14,H-12);C.textAlign='right';C.fillText('TIME  '+Math.ceil(timeLeft),W-14,H-12);C.textAlign='center';C.fillText('COMBO x'+combo,(W/2),(H-12))
     if(timeLeft<=5&&timeLeft>0){C.fillStyle='#ef4444';C.font='bold 20px system-ui';C.fillText('HURRY!',W/2,H-64)}
     if(!started){C.fillStyle='rgba(3,6,13,.6)';C.fillRect(0,0,W,H);C.fillStyle='#fff';C.font='bold 24px system-ui';C.textAlign='center';C.fillText('TAP THE BUBBLES',W/2,H/2-10);C.font='16px system-ui';C.fillText('pop fast to build combos · gold bubbles are worth 3x',W/2,H/2+22)}
     if(dying){C.fillStyle='rgba(3,6,13,.78)';C.fillRect(0,0,W,H);C.fillStyle='#22c55e';C.font='bold 30px system-ui';C.textAlign='center';C.fillText('TIME UP',W/2,H/2-14);C.fillStyle='#fff';C.font='17px system-ui';C.fillText('tap anywhere to restart',W/2,H/2+16)}}
   let dt=0
   return{update:function(d){dt=d;update(d)},draw};}
  window.Games={bubblepop:factory};
})();