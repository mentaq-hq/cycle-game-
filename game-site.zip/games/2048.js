(function(){const T={2:'#0f1524',4:'#1e2a4a',8:'#2a3b5f',16:'#364a73',32:'#435987',64:'#52699c',128:'#6c80b8',256:'#8d9dd6',512:'#b5c6f0',1024:'#d8e1f3',2048:'#ffffff'};
function factory(canvas,api){const C=api.ctx,W=api.w,H=api.h;const N=4,KI=96,GP=14,BG='#162038';let G=null,SRC=0,HIGH=api.high.get(api.config.gameId),LOST=false;
 function newGrid(){return Array(N).fill(null).map(()=>Array(N).fill(0))}
 function reset(){G=newGrid();SRC=0;HIGH=api.high.get(api.config.gameId);LOST=false;spawn();spawn();}
 function spawn(){const f=[];for(let y=0;y<N;y++)for(let x=0;x<N;x++)if(G[y][x]===0)f.push({x,y});if(!f.length)return false;const t=f[Math.floor(Math.random()*f.length)];G[t.y][t.x]=Math.random()<.9?2:4;return true}
 function lineMove(a){let arr=a.filter(v=>v!==0),res=[],skip=false;for(let i=0;i<arr.length;i++){if(arr[i]===arr[i+1]&&!skip){res.push(arr[i]*2);SRC+=arr[i]*2;api.score(SRC);skip=true;i++}else res.push(arr[i],skip=false)}while(res.length<N)res.push(0);return res}
 function rotate90(a){return a.map((r,i)=>a.map(c=>c[N-1-i]))}
 function lineMove(a){let arr=a.filter(v=>v!==0),res=[],skip=false;for(let i=0;i<arr.length;i++){if(arr[i]===arr[i+1]&&!skip){res.push(arr[i]*2);SRC+=arr[i]*2;api.score(SRC);skip=true;i++}else{res.push(arr[i]);skip=false}}while(res.length<N)res.push(0);return res}
 function moved(old){for(let y=0;y<N;y++)for(let x=0;x<N;x++)if(G[y][x]!==old[y][x])return true;return false}
 function move(dir){const old=G.map(r=>r.slice());let grid;
  if(dir==='left')grid=G.map(r=>lineMove(r));
  else if(dir==='right')grid=G.map(r=>lineMove(r.slice().reverse()).reverse());
  else if(dir==='up'){grid=newGrid();for(let x=0;x<N;x++){let col=[];for(let y=0;y<N;y++)col.push(G[y][x]);col=lineMove(col);for(let y=0;y<N;y++)grid[y][x]=col[y]}}
  else{grid=newGrid();for(let x=0;x<N;x++){let col=[];for(let y=0;y<N;y++)col.push(G[N-1-y][x]);col=lineMove(col).reverse();for(let y=0;y<N;y++)grid[y][x]=col[y]}}
  if(moved(old)){G=grid;spawn()}
 function checkLost(){for(let y=0;y<N;y++)for(let x=0;x<N;x++){if(G[y][x]===0)return false;const v=G[y][x];if((y>0&&G[y-1][x]===v)||(y<N-1&&G[y+1][x]===v)||(x>0&&G[y][x-1]===v)||(x<N-1&&G[y][x+1]===v))return false}return true}
 function update(dt){if(E.KB.hit('ArrowUp'))move('up');else if(E.KB.hit('ArrowDown'))move('down');else if(E.KB.hit('ArrowLeft'))move('left');else if(E.KB.hit('ArrowRight'))move('right');
  if(checkLost()&&!LOST){LOST=true;END(SRC,'No more moves','You reached '+2048)}
 function draw(){C.fillStyle='#020408';C.fillRect(0,0,W,H);C.shadowBlur=0;C.fillStyle=BG;C.fillRect(0,0,W,H-KI*4-GP*(3));const offX=(W-KI*4-GP*3)/2,offY=(H-(KI*4+GP*3))/2;C.strokeStyle='#2e3f63';C.lineWidth=3;C.beginPath();for(let i=0;i<=N;i++){C.moveTo(offX+i*(KI+GP),offY);C.lineTo(offX+i*(KI+GP),offY+N*(KI+GP));C.moveTo(offX,offY+i*(KI+GP));C.lineTo(offX+N*(KI+GP),offY+i*(KI+GP));}C.stroke();
  for(let y=0;y<N;y++)for(let x=0;x<N;x++){const v=G[y][x];if(v===0)continue;const b=T[v]||'#9aa6bc';const ox=offX+x*(KI+GP)+4,oy=offY+y*(KI+GP)+4;C.fillStyle=b;C.beginPath();C.roundRect(ox,oy,KI-8,KI-8,8);C.fill();C.font=`bold ${v>=1000?28:v>=100?30:32}px system-ui`;C.fillStyle=v<=128?'#c9d5e6':'#fff';C.textAlign='center';C.textBaseline='middle';C.fillText(v,ox+KI/2,oy+KI/2)}C.fillStyle='#9aa6bc';C.font='bold 15px system-ui';C.textAlign='left';C.fillText('SCORE  '+SRC,12,H-14);C.textAlign='right';C.fillText('BEST  '+HIGH,W-12,H-14)}
 return{update,draw};}
window.Games={2048:factory};})();