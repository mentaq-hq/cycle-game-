(function(){
  const OPS=['+','-','×','÷'];
  function factory(canvas,api){const C=api.ctx,W=api.w,H=api.h;let solved=0,streak=0,timer=8,buffer='',problem=null,difficulty=0,BEST=api.high.get(api.config.gameId);
   function gen(){const op=OPS[Math.min(3,difficulty)];let a,b,r;if(op==='+'){a=1+Math.floor(Math.random()*(10+difficulty));b=1+Math.floor(Math.random()*(10+difficulty));r=a+b}
     else if(op==='-'){a=2+difficulty+Math.floor(Math.random()*8);b=1+Math.floor(Math.random()*a);r=a-b}
     else if(op==='×'){a=1+Math.floor(Math.random()*(4+difficulty));b=1+Math.floor(Math.random()*9);r=a*b}
     else{b=2+Math.floor(Math.random()*10);r=1+Math.floor(Math.random()*10);a=b*r}problem={op:op,a:a,b:b,res:r}}
   function update(dt){if(timer>0)timer-=dt;else{END(solved,'Time\'s up!','Solved '+solved+' problems')}
     if(buffer.length===0)return;const v=parseInt(buffer,10);if(!Number.isNaN(v)&&v===problem.res){solved++;streak++;difficulty=Math.floor(solved/5);timer=Math.max(1.8,8-streak*.12);buffer='';gen()}
   }
   function append(d){if(buffer.length<4)buffer+=d;}
   function back(){buffer=buffer.slice(0,-1);}
   function submit(){if(buffer.length===0)return;const v=parseInt(buffer,10);if(Number.isNaN(v)||v!==problem.res){END(solved,'Wrong answer!','You solved '+solved+' problems')}}
   function draw(){C.fillStyle='#060a14';C.fillRect(0,0,W,H);C.fillStyle='#162038';C.fillRect(0,H-38,W,38);C.fillStyle='#2a3f66';C.fillRect(0,H-38,(timer/8)*(W-6),38)
     C.fillStyle='#9aa6bc';C.font='bold 15px system-ui';C.textAlign='left';C.fillText('SCORE  '+solved,14,H-12);C.textAlign='right';C.fillText('STREAK x'+streak,W-14,H-12);C.textAlign='center';C.fillText('BEST  '+BEST,W/2,H-12)
     C.fillStyle='#eef2f7';C.font='bold 44px system-ui';C.textAlign='center';C.fillText(problem?a+' '+problem.op+' '+b+' = ?',W/2,H/2-24)
     C.fillStyle='#22d3ee';C.font='bold 36px system-ui';C.textAlign='center';C.fillText(buffer||'?',W/2,H/2+42)
     C.fillStyle='#fff';C.font='bold 20px system-ui';C.textAlign='center';C.fillText('solve fast · digit keys or pads',W/2,H/2+92)}
   function initPad(){const p=canvas.parentElement.querySelector('#game-pads');p.querySelectorAll('button').forEach(b=>{b.onclick=(ev)=>{ev.preventDefault();if(b.classList.contains('dbk'))back();else if(b.classList.contains('done'))submit();else if(b.dataset.k&&b.dataset.k!=='up'&&b.dataset.k!=='down'&&b.dataset.k!=='left'&&b.dataset.k!=='right')append(b.textContent)}})}
   const keyDown=function(e){if(/^[0-9]$/.test(e.key))append(e.key);else if(e.key==='Backspace')back();else if(e.key==='Enter')submit()}
   window.addEventListener('keydown',keyDown,false);window.addEventListener('keyup',(e)=>{if(e.key==='Backspace'||e.key==='Enter'){}},false)
   gen();initPad();return{update,draw};}
  window.Games={mathracer:factory};
})();