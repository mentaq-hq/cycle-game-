(function(){
  const G=2000, JUMP=-565, RADIUS=18, GROUND=H-72, SPEED0=390;
  function factory(canvas,api){const C=api.ctx,W=api.w,H=api.h;let px=140,py=H/2,vy=0,landed=true,spikes=[],score=0,high=api.high.get(api.config.gameId),started=false,dying=false,speed=SPEED0,lastSpikeX=0,tailAcc=0;let bestT=0,lastTime=performance.now();
   function reset(){px=140;py=H/2;vy=0;landed=true;spikes=[];score=0;speed=SPEED0;started=false;dying=false;lastSpikeX=0;tailAcc=0;bestT=api.high.get(api.config.gameId)}
   function update(dt){if(!started&&E.KB.hit('ArrowUp'))started=true;if(dying)return;vy+=G*dt;py+=vy*dt;for(let i=spikes.length-1;i>=0;i--){spikes[i].x-=speed*dt;spikes[i].t-=speed*dt*spikes[i].h/speed;spikes[i].y-=speed*dt*0;spikes[i].t=speed*dt*spikes[i].h/speed}
     if(lastSpikeX<W-340){const w=50,h=50+Math.random()*50;spikes.push({x:lastSpikeX+W-260,w:w,h:h})}for(let i=spikes.length-1;i>=0;i--){if(spikes[i].x<-90)spikes.splice(i,1)}
     if(py+RADIUS>=GROUND){py=GROUND-RADIUS;vy=0;landed=true}
     else{landed=false}for(let s of spikes){if(insideCircle(px,py,RADIUS*0.72,{l:s.x,r:s.x+s.w,t:s.y,b:s.y+s.h}))die()}
     if(started){score+=dt*8;const el=(performance.now()-lastTime)/1000;if(el>0.016){lastTime=performance.now();if(tailAcc>0.09){tailAcc-=0.09;E.spawn(px-(landed?0:18),py+(landed?RADIUS:0),'#ef4444',5,8)}}}
   function die(){if(dying)return;dying=true;E.audio.play('bad');END(score(),'Game Over','Space scored '+score.toFixed(0))}
   const onClick=function(x,y){if(dying){reset();return}if(landed){vy=JUMP;E.spawn(px,py+RADIUS,'#ef4444',8,16,'circle');E.spawn(px,py+RADIUS,'#ff9a9e',5,12)}}
   window.addEventListener('pointerdown',(e)=>onClick(e.clientX,e.clientY),{passive:false});
   function insideCircle(cx,cy,r,rect){const lx=Math.max(rect.l Math.min(cx,rect.r));const ly=Math.max(rect.t Math.min(cy,rect.b));const dx=cx-lx;const dy=cy-ly;return(dx*dx+dy*dy)<r*r}
   function draw(){C.fillStyle='#060a14';C.fillRect(0,0,W,H);const P=performance.now()/400%2;for(let i=0;i<18;i++){const sx=((P*7+i*97)%W),sy=((P*3+i*41)%H);C.fillStyle=i%5==0?'#fbbf24':'#9aa6bc';C.globalAlpha=.35+.65*(.5+.5*Math.sin(performance.now()/500+i));C.fillRect(sx,sy,2,2);C.globalAlpha=1}
     C.fillStyle='#141e32';C.fillRect(0,GROUND,W,H-GROUND);C.strokeStyle='#2a4a7a';C.lineWidth=2;C.beginPath();C.moveTo(0,GROUND);C.lineTo(W,GROUND);C.stroke();C.shadowBlur=10;C.shadowColor='#22c55e';C.fillStyle='#0f1a2e';C.strokeStyle='#22c55e';C.lineWidth=2.5;for(let s of spikes){C.beginPath();C.moveTo(s.x,s.y);C.lineTo(s.x,s.y+s.h);C.lineTo(s.x+s.w,s.y+s.h);C.lineTo(s.x+s.w,s.y);C.closePath();C.fill();C.stroke()}C.shadowBlur=0;
     C.fillStyle='#fff';C.shadowBlur=14;C.shadowColor='#ef4444';C.beginPath();C.arc(px,py,RADIUS,0,Math.PI*2);C.fill();C.shadowBlur=0;C.fillStyle='#3a4a66';C.font='bold 15px system-ui';C.textAlign='left';C.fillText('SCORE  '+score.toFixed(0),10,H-14);C.textAlign='right';C.fillText('BEST  '+bestT.toFixed(0),W-10,H-14)
     if(!started){C.fillStyle='rgba(3,6,13,.6)';C.fillRect(0,0,W,H);C.fillStyle='#fff';C.font='bold 24px system-ui';C.textAlign='center';C.fillText('TAP TO JUMP',W/2,H/2-10);C.font='16px system-ui';C.fillText('tap when you land · jump over the red walls',W/2,H/2+20)}
     if(dying){C.fillStyle='rgba(3,6,13,.78)';C.fillRect(0,0,W,H);C.fillStyle='#ef4444';C.font='bold 30px system-ui';C.textAlign='center';C.fillText('CRASHED!',W/2,H/2-14);C.fillStyle='#fff';C.font='17px system-ui';C.fillText('tap anywhere to restart',W/2,H/2+16)}}
   return{update,draw};}
  window.Games={spacejump:factory};
})();