(function(){
  function factory(canvas,api){const C=api.ctx,W=api.w,H=api.h;let score=0,high=api.high.get(api.config.gameId),quadrant=-1,flashActive=false,flashStart=0,dur=1000,streak=0,bestStreak=high,lastReaction=null,toast='';const Q=['tl','tr','bl','br'];
   function reset(){score=0;high=api.high.get(api.config.gameId);streak=0;bestStreak=high;lastReaction=null;toast='';newRound()}
   function newRound(){quadrant=Math.floor(Math.random()*4);flashActive=true;flashStart=performance.now();dur=Math.max(250,1100-Math.min(25,Math.floor(streak*30)))}
   function resolve(x,y){if(!flashActive)return;const now=performance.now();if(now<flashStart+30)return;const qx=(x>W/2?1:0),qy=(y>H/2?1:0);const q=qy*2+qx;
     if(q===quadrant){const ms=now-flashStart;lastReaction=ms;score+=100+streak*12;streak++;if(streak>bestStreak)bestStreak=streak;api.score(score)}else{streak=0;toast='Missed!';api.score(score)}
     newRound()}
   const click=function(evX,evY){resolve(evX,evY)};window.addEventListener('pointerdown',(e)=>click(e.clientX,e.clientY),{passive:false})
   function update(dt){if(flashActive&&performance.now()>=flashStart+dur){streak=0;toast='Too slow!';api.score(score);newRound()}}
   function draw(){C.fillStyle='#060a14';C.fillRect(0,0,W,H);const P=performance.now()/500%1;for(let i=0;i<3;i++){C.fillStyle='rgba(168,85,247,'+(.04+(P+i*.05))+')';C.beginPath();C.arc(W*(.2+.3*i),H*(.25+.25*i),W*.18,0,Math.PI*2);C.fill()}
     C.strokeStyle='rgba(148,163,184,.7)';C.lineWidth=3;C.beginPath();C.moveTo(0,H/2);C.lineTo(W,H/2);C.moveTo(W/2,0);C.lineTo(W/2,H);C.stroke();C.lineWidth=2
     if(flashActive){const qx=(quadrant%2)*W/2,qy=Math.floor(quadrant/2)*H/2;C.globalAlpha=.18+.32*(.5+.5*Math.sin(performance.now()/100));C.fillStyle='#22d3ee';C.shadowBlur=24;C.shadowColor='#22d3ee';C.fillRect(qx,qy,W/2,H/2);C.shadowBlur=0;C.globalAlpha=1}}
     C.fillStyle='#9aa6bc';C.font='bold 14px system-ui';C.textAlign='left';C.fillText('SCORE   '+score,12,H-12);C.textAlign='right';C.fillText('STREAK x'+streak,W-12,H-12);C.textAlign='center';C.fillText('BEST x'+bestStreak,W/2,H-12)
     C.fillStyle='#fff';C.font='bold 20px system-ui';C.textAlign='center';C.fillText('tap the flashing quadrant · react fast',W/2,H/2-6)
     if(toast){const col=toast==='Missed!'?'#ef4444':'#f59e0b';C.fillStyle=col;C.font='bold 26px system-ui';C.textAlign='center';C.fillText(toast,W/2,H/2-44);if(lastReaction)C.font='15px system-ui';C.fillText('last: '+lastReaction.toFixed(0)+'ms',W/2,H/2+8)}
     if(!flashActive){C.fillStyle='#060a14';C.fillRect(0,0,W,H)}}
   return{update,draw};}
  window.Games={quadrant:factory};
})();