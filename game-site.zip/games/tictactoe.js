(function(){
  const AI=2, PL=1;
  function factory(canvas,api){
    const C=api.ctx, W=api.w, H=api.h;
    let MODE=null, N=3, board=null, winner=null, AIturn=false;
    let SZ=0, offX=0, offY=0;
    const modes=[{id:'ttt',title:'Tic-Tac-Toe (3x3)',n:3},{id:'gomoku',title:'Gomoku (15x15)',n:15}];
    const DXDY=[[0,1],[1,0],[1,1],[-1,1]];
    let mode=modes[0];

    function reset(){board=Array(mode.n).fill(null).map(()=>Array(mode.n).fill(0));winner=null;AIturn=false;}
    function computeBoard(){SZ=Math.min(W,H)*0.62/mode.n;offX=(W-mode.n*SZ)/2;offY=(H-mode.n*SZ)/2;}
    function drawGrid(){C.fillStyle='#162038';C.fillRect(0,0,W,H);C.strokeStyle='#35466b';C.lineWidth=3;C.beginPath();for(let i=0;i<=mode.n;i++){C.moveTo(offX+i*SZ,offY);C.lineTo(offX+i*SZ,offY+mode.n*SZ);C.moveTo(offX,offY+i*SZ);C.lineTo(offX+mode.n*SZ,offY+i*SZ)}C.stroke();}
    function drawMark(x,y,val){C.shadowBlur=16;C.shadowColor=val===PL?'#22d3ee':'#f472b6';const R=0.32*SZ;
      if(val===PL){C.strokeStyle='#ffffff';C.lineWidth=6;C.beginPath();C.moveTo(x-R,y-R);C.lineTo(x+R,y+R);C.moveTo(x+R,y-R);C.lineTo(x-R,y+R);C.stroke()}
      else{C.fillStyle='#0a1020';C.beginPath();C.arc(x,y,R,0,Math.PI*2);C.fill();C.strokeStyle='#ffffff';C.lineWidth=6;C.beginPath();C.arc(x,y,R,0,Math.PI*2);C.stroke()}C.shadowBlur=0;}
    function checkWin(b,n){for(let y=0;y<n;y++)for(let x=0;x<n;x++){const v=b[y][x];if(v===0||v===null)continue;if(x+3<n&&b[y][x+1]===v&&b[y][x+2]===v)return v;if(y+3<n&&b[y+1][x]===v&&b[y+2][x]===v)return v;if(x+3<n&&y+3<n&&b[y+1][x+1]===v&&b[y+2][x+2]===v)return v;if(x+3<n&&y-3>=0&&b[y-1][x+1]===v&&b[y-2][x+2]===v)return v}return null}
    function emptyCells(b,n){let arr=[];for(let y=0;y<n;y++)for(let x=0;x<n;x++)if(b[y][x]===0)arr.push({x:x,y:y});return arr}
    function minimax(b,who){const w=checkWin(b,mode.n);if(w===PL)return 10;if(w===AI)return -10;const e=emptyCells(b,mode.n);if(e.length===0)return 0;let best=null;for(const c of e){b[c.y][c.x]=who;const sc=minimax(b,who===PL?AI:PL);b[c.y][c.x]=0;if(who===AI){if(best===null||sc>best.sc)best={sc,c}}else{if(best===null||sc<best.sc)best={sc,c}}}return best?best.sc:0;}
    function aiTurn(){if(winner)return;const e=emptyCells(board,mode.n);if(e.length===0){winner='draw';END(score(),'Draw!','Both blocked');return}
      let pick;if(mode.id==='ttt'){let best=null;for(const c of e){board[c.y][c.x]=AI;const sc=minimax(board,PL);board[c.y][c.x]=0;if(best===null||sc>best.sc)best=c}pick=best}
      else{let best=null,bscore=-Infinity;for(const c of e){let oc=0,pc=0;for(const d of DXDY){let tx=c.x+d[0],ty=c.y+d[1];while(tx>=0&&tx<mode.n&&ty>=0&&ty<mode.n&&board[ty][tx]===AI){pc++;tx+=d[0];ty+=d[1]}tx=c.x-d[0];ty=c.y-d[1];while(tx>=0&&tx<mode.n&&ty>=0&&ty<mode.n&&board[ty][tx]===AI){pc++;tx-=d[0];ty-=d[1]}tx=c.x+d[0];ty=c.y+d[1];while(tx>=0&&tx<mode.n&&ty>=0&&ty<mode.n&&board[ty][tx]===AI){oc++;tx+=d[0];ty+=d[1]}tx=c.x-d[0];ty=c.y-d[1];while(tx>=0&&tx<mode.n&&ty>=0&&ty<mode.n&&board[ty][tx]===AI){oc++;tx-=d[0];ty-=d[1]}const block=oc*1.8+pc*0.3;if(block>bscore){bscore=block;best=c}}}pick=best}
      board[pick.y][pick.x]=AI;AIturn=false;draw();winner=checkWin(board,mode.n);if(winner===AI)END(score(),'You lost!','Gomoku — the AI wins');else if(emptyCells(board,mode.n).length===0)END(score(),'Draw!','Both blocked')}
    function score(){let tot=0;for(let y=0;y<mode.n;y++)for(let x=0;x<mode.n;x++)if(board[y][x]!==0)tot++;return tot+mode.n*mode.n;}
    function place(x,y){if(AIturn||winner)return;const j=Math.floor((y-offY)/SZ),i=Math.floor((x-offX)/SZ);if(i<0||i>=mode.n||j<0||j>=mode.n||board[j][i]!==0)return;board[j][i]=PL;draw();winner=checkWin(board,mode.n);if(winner){END(score(),'You win!','Nicely played');return}AIturn=true;setTimeout(aiTurn,150)}
    function switchMode(i){mode=modes[i];N=mode.n;reset();draw()}
    function update(dt){}
    function draw(){computeBoard();drawGrid();for(let y=0;y<mode.n;y++)for(let x=0;x<mode.n;x++){if(board[y][x]!==0)drawMark(offX+x*SZ+SZ/2,offY+y*SZ+SZ/2,board[y][x])}if(winner==='draw'){}
      C.fillStyle='#9aa6bc';C.font='bold 15px system-ui';C.textAlign='left';C.fillText('BEST  '+api.high.get(api.config.gameId),10,H-14);}
    const onClick=function(evX,evY){place(evX,evY)};
    window.addEventListener('pointerdown',(e)=>onClick(e.clientX,e.clientY),{passive:false});

    function initPad(){const p=canvas.parentElement.querySelector('#game-pads');p.innerHTML='<div class="num-pad" style="grid-template-columns:1fr 1fr"><button class="nkey m0">'+modes[0].title+'</button><button class="nkey m1">'+modes[1].title+'</button></div>';
      p.querySelectorAll('button').forEach((b,i)=>b.onclick=()=>switchMode(i));}

    initPad();reset();return{update,draw};}
  window.Games={tictactoe:factory};
})();