(function(){
  const PW=110,PBH=16,RB=10,ROWS=5,COLS=9,GAP=4,C0=['#ef4444','#f97316','#eab308','#22c55e','#06b6d4'];
  const BRW=(W-GAP*(COLS+1))/COLS,BRH=22,GND=H-56;
  function factory(canvas,api){const C=api.ctx,W=api.w,H=api.h;let pX=W/2,pbx=W/2,ball={x:W/2,y:GND-RB,vx:0,vy:0},lives=3,score=0,high=api.high.get(api.config.gameId),started=false,level=1,dying=false;let bricks=[];
   function reset(){pX=W/2;pbx=W/2;ball={x:W/2,y:GND-RB,vx:0,vy:0};lives=3;score=0;high=api.high.get(api.config.gameId);started=false;level=1;dying=false;bricks=[]}
   function makeBricks(){bricks=[];for(let r=0;r<ROWS;r++)for(let c=0;c<COLS;c++){bricks.push({x:GAP+c*(BRW+GAP),y:72+r*(BRH+GAP),w:BRW,h:BRH,alive:true,col:C0[r]})}}
   function launch(){ball.x=pX;ball.y=GND-RB;ball.vx=0;ball.vy=-(260+6*(level-1))+(Math.random()*2)}
   function spark(x,y,c,kind='square'){E.spawn(x,y,c,7,12,kind)}
   function resetBall(){ball.x=pX;ball.y=GND-RB;ball.vx=0;ball.vy=0}
   function update(dt){if(dying)return;if(!started&&(E.KB.hit('ArrowLeft')||E.KB.hit('ArrowRight')||E.KB.hit('KeyA')||E.KB.hit('KeyD')))started=true;pX=pbx-PW/2;
     ball.x+=ball.vx*dt;ball.y+=ball.vy*dt;const BL=ball.x-RB,BR=ball.x+RB,BT=ball.y-RB,BB=ball.y+RB,PL=pX-PW/2,PR=pX+PW/2;
     if(BL<=0||BR>=W){ball.vx=-ball.vx;spark(ball.x,ball.y,'#fff',undefined)}
     if(BT<=0){ball.y=RB;ball.vy=-ball.vy}
     if(BB>GND){if(BL<=PR&&BR>=PL&&BT<=GND&&BB>=GND-PBH){ball.vy=-Math.abs(ball.vy)*1.05;ball.vx+=(ball.x-pX)/PW*12}else{lives--;spark(ball.x,ball.y,'#ef4444',undefined);if(lives<=0){dying=true;END(score(),'Game Over','Brick Blaster scored '+score)}else{resetBall();spawnSpark}}}
     if(ball.vy>0){let hit=false;for(const b of bricks){if(!b.alive)continue;if(BL<b.x+b.w&&BR>b.x&&BT<b.y+b.h&&BB>b.y){b.alive=false;score+=10*level;spark(b.x+b.w/2,b.y+b.h/2,b.col);spark(b.x+b.w/2,b.y+b.h/2,'#fff',undefined);ball.vy=-Math.abs(ball.vy);hit=true;break}}}
     if(hit){for(let i=0;i<8;i++)spark(ball.x,ball.y,'#fff',undefined)}
     if(bricks.every(k=>!k.alive)){level++;makeBricks();resetBall();ball.vy=-(260+6*(level-1));ball.vx=(Math.random()*0.8-0.4)*(260+6*(level-1));score+=50}}
     function spawnSpark(){ball.x=pX;ball.y=GND-RB;ball.vx=0;ball.vy=-(260+6*(level-1))}
   }
   function draw(){C.fillStyle='#060a14';C.fillRect(0,0,W,H);C.fillStyle='#0f172a';C.fillRect(0,GND,W,H-GND);C.strokeStyle='#2a3f66';C.lineWidth=2;C.beginPath();C.moveTo(0,GND);C.lineTo(W,GND);C.stroke()
     C.shadowBlur=0;for(const b of bricks){if(!b.alive)continue;C.fillStyle='#16223a';C.beginPath();C.roundRect(b.x+1,b.y+1,b.w-2,b.h-2,3);C.fill();C.fillStyle=b.col;C.beginPath();C.roundRect(b.x+2,b.y+2,b.w-4,b.h-4,2);C.fill()}
     C.fillStyle='#16223a';C.shadowBlur=8;C.shadowColor='#38bdf8';C.beginPath();C.roundRect(pX-PW/2,GND-PBH,PW,PBH,6);C.fill();C.shadowBlur=0
     C.fillStyle='#fff';C.shadowBlur=12;C.shadowColor='#38bdf8';C.beginPath();C.arc(ball.x,ball.y,RB,0,Math.PI*2);C.fill();C.shadowBlur=0
     C.fillStyle='#9aa6bc';C.font='bold 15px system-ui';C.textAlign='left';C.fillText('SCORE  '+score,10,H-14);C.textAlign='center';C.fillText('LEVEL '+level+'   LIVES '+lives,W/2,H-14);C.textAlign='right';C.fillText('BEST  '+high,W-10,H-14)
     if(!started){C.fillStyle='rgba(3,6,13,.6)';C.fillRect(0,0,W,H);C.fillStyle='#fff';C.font='bold 24px system-ui';C.textAlign='center';C.fillText('TAP TO LAUNCH',W/2,H/2-10);C.font='16px system-ui';C.fillText('tap to launch · mouse or touch to move the paddle',W/2,H/2+22)}
     if(dying){C.fillStyle='rgba(3,6,13,.78)';C.fillRect(0,0,W,H);C.fillStyle='#ef4444';C.font='bold 30px system-ui';C.textAlign='center';C.fillText('GAME OVER',W/2,H/2-14);C.fillStyle='#fff';C.font='17px system-ui';C.fillText('tap anywhere to restart',W/2,H/2+16)}}
   function launch(){if(lives>0){ball.y=GND-RB;ball.vx=(Math.random()*0.8-0.4)*(260+6*(level-1));ball.vy=-(260+6*(level-1))-Math.random()}
   const ptr=function(x,y){pbx=Math.max(PW/2,Math.min(W-PW/2,x))};
   const click=function(evX,evY){if(dying){reset();return}if(ball.vy===0){launch()}else if(!started&&E.KB.hit('ArrowLeft')){started=true}}
   window.addEventListener('pointerdown',(e)=>click(e.clientX,e.clientY),{passive:false})
   return{update,draw,pointer:ptr};}
  window.Games={brickblaster:factory};
})();