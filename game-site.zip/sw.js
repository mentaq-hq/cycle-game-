// NovaArcade Service Worker — cache-first, works offline
const CACHE='novaarcade-v1';
const ASSETS=[
'/','/index.html','/style.css','/app.js','/engine.js','/robots.txt','/manifest.json',
'/assets/icon-192.png','/assets/icon-512.png',
'/games/snake.js','/games/2048.js','/games/memory.js','/games/tictactoe.js',
'/games/featherdash.js','/games/spacejump.js','/games/brickblaster.js',
'/games/bubblepop.js','/games/quadrant.js','/games/mathracer.js'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)).then(()=>self.skipWaiting()))});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==CACHE).map(x=>caches.delete(x)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{if(e.request.method!=='GET')return;e.respondWith(caches.match(e.request).then(c=>c||fetch(e.request).then(r=>{if(!r||r.status!==200||r.type!=='basic')return r;const c=r.clone();caches.open(CACHE).then(x=>x.put(e.request,c));return r}).catch(()=>caches.match(e.request))))});
