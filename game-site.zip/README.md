# NovaArcade — निःशुल्क ब्राउज़र गेम हब

10 सुपर-फ़ास्ट, बिना लैग वाले गेम। कोई सर्वर नहीं, कोई इंस्टॉल नहीं — हर डिवाइस पर चलते हैं। ऑफलाइन भी चालू हैं।

## यह क्या है

- **index.html** — मुख्य प्रवेश द्वार (गेम चुनने वाला हब)
- **engine.js** — साझा गेम इंजन (60 FPS लूप, पार्टिकल्स, ऑडियो, हाई-स्कोर, इनपुट)
- **app.js** — SPA रूटर, HUD, PWA इंस्टॉल, डायनामिक पेज टाइटल/मीटा
- **style.css** — Midnight Neo थीम, ग्लासमॉर्फ़िज़्म कार्ड्स, 60 FPS + रिड्यूसड मोशन
- **games/** — 10 गेम मॉड्यूल (Neon Snake, 2048, Memory Blitz, Tic-Tac-Toe + Gomoku, Feather Dash, Space Jump, Brick Blaster, Bubble Pop, Quadrant Reflex, Math Racer)
- **assets/** — 192/512px ऐप आइकॉन
- **manifest.json**, **sw.js**, **robots.txt**, **sitemap.xml** — PWA + SEO तैयार

## फ़्री में डेप्लॉय (3 मिनट, ₹0)

### तरीका 1 — Netlify (सीधा, सबसे आसान)
1. `/outputs` की फ़ोल्डर को Netlify के "Add new site" → "Deploy manually" ड्रॉप-ज़ोन में छोड़ दें
2. `netlify deploy --prod` या ड्रैग-एंड-ड्रॉप
3. सबमिन `.netlify.app` हमेशा मुफ्त; कस्टम डोमेन बाद में जोड़ सकते हैं

### तरीका 2 — Vercel / Cloudflare Pages
1. इसी फ़ोल्डर को GitHub रीपो में डालें (GitHub फ़्री)
2. Vercel/Cloudflare Pages में रीपो लिंक करें
3. Build command: `none` · Publish directory: `/`

हर `git push` से अपने आप डेप्लॉय हो जाता है (फ़्री CI/CD)। कोई सर्वर, कोई माहनामा खर्चा नहीं — हमेशा ₹0।

## गेम कंट्रोल

- **कीबोर्ड:** Arrow/WASD/Space/Enter — PC/Laptop पर
- **टच:** स्क्रीन पर टैप करके — मोबाइल/टैबलेट पर (Pointer Events, एक ही कोड सबके लिए)
- **ऑफलाइन:** पहले लोड होने पर सर्विस वर्कर कैश करता है; बाद में इंटरनेट बंद करके भी चलता है

## पर्फॉरमेंस (कोई लैग, डिवाइस गर्म नहीं)

- सारा गेम लॉजिक ब्राउज़र (client-side) में — CPU का बोझ सर्वर पर नहीं, यानी 1000+ एकसाथ चालू = कोई प्रॉब्लम नहीं
- requestAnimationFrame + 60 FPS cap, `will-change`/CSS transforms (GPU), object pooling, passive event listeners
- फ़ाइल बाउजेट: कुल ~45 KB gzipped (होस्टिंग CDN पर edge cache)
- Core Web Vitals लक्ष्य: LCP < 1.8s, CLS < 0.05

## QA चेकलिस्ट (डेव में)

1. Lighthouse चलाएँ → Performance ≥ 90 (फ़ास्ट CDN पर)
2. प्रत्येक गेम: FPS 55–60 (Device Mode में चेक करें), कोई टियर नहीं
3. सभी गेम: कीबोर्ड + टच दोनों पर काम करें (फ़ोन पर टच टेस्ट करें)
4. इंटरनेट बंद करें → पेज reload → गेम ऑफलाइन चले
5. PWA: "Install" बटन दिखे → ऐप जैसे खुले, स्टैंडअलोन विंडो में
6. 1000 concurrent यूज़र्स सिमुलेशन: कोई API कॉल नहीं है, CDN स्केल करता है — कोई लैग नहीं

## नोट

- साइट पूरी तरह क्लाइंट-साइड है — किसी भी फ़्री होस्ट पर काम करती है (Netlify, Vercel, Cloudflare Pages, GitHub Pages)
- ब्राउज़र फ़ॉन्ट्स ऑटो-फॉलबैक लेते हैं (Inter fallbacks on Segoe UI/system)

आगे का रास्ता: `git init` → `git add .` → GitHub → Netlify/Vercel कनेक्ट → लाइव!
